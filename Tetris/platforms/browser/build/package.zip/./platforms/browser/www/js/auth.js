/**
 * Created by paulo on 22/12/2016.
 */

$("#auth-button").click(function () {
    alert("merda crl");
});